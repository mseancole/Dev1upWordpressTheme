<?php if ( ! function_exists( 'dynamic_sidebar' ) || ! dynamic_sidebar( 'jumbotron' ) ) : ?>

<div class="jumbotron">
	<h1>About Me</h1>

	<p>Enter some information about yourself.</p>
</div>

<?php endif ?>