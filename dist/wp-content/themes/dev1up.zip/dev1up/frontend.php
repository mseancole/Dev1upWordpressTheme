<div class="section row" id="frontend">
	<div class="col-xs-12 col-sm-6 col-md-8 col-md-offset-4">
		<div class="well">
			<h2>Well, this is just embarasing... There's nothing here!</h2>
		</div>
	</div>
</div>