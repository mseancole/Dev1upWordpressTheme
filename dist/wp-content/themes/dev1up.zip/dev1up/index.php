<?php
get_header();

$_SPLIT = split_site_name();

include 'main.php';

include 'blog.php';

//include 'frontend.php';

//include 'backend.php';

get_footer();
?>