<article id="post-<?php the_ID(); ?>" class="well <?php echo get_post_class(); ?>">

	<?php include ( is_single() ? 'single_header' : 'posts_header' ) . '.php'; ?>

</article>