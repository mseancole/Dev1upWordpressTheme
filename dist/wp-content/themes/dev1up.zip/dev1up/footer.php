	</div>

	<script src="<?php echo get_template_directory_uri(); ?>/assets/scripts/vendor/jquery-2.1.4.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/scripts/vendor/bootstrap.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/scripts/main.min.js"></script>
</body>

</html>