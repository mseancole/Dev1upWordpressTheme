<div class="row about_widget">
	<div class="col-xs-12">

		<?php if ( ! function_exists( 'dynamic_sidebar' ) || ! dynamic_sidebar( 'about' ) ) : ?>

		<div class="row">
			<div class="col-xs-6 col-md-4">Developer:</div>
			<div class="col-xs-12 col-sm-6 col-md-8">
				<div class="textwidget">Sean Cole</div>
			</div>
		</div>

		<?php endif ?>

	</div>
</div>